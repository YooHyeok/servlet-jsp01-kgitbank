package lab.web.el;

public class CeilEL {
	public static double pageCeil(double num) {
		return Math.ceil(num);
	}
}
