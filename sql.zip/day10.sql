--19.12.30 day10 -

create table emps as (select * from employees);
create table empss as (select * from employees where 1=2);
select * from emps;
select * from empss;

alter table emps add (col1 number(3,0) null);
alter table emps rename column col1 to last_col;
alter table emps modify column (last_col varchar2(30));
alter table emps drop column last_col;
alter table emps drop column last_col;

drop table emps;


truncate table emps;
