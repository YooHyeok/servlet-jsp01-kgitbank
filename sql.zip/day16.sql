create table board(
bbsno number not null primary key,
userid varchar2(20) not null,
password varchar2(12) not null,
subject varchar2(50) not null,
content varchar2(4000) null,
writedate date not null,
masterid number null,
readcount number null,
replynumber number null,
replystep number null,
constraint fk_mem_id foreign key(userid) references member(userid)
);

drop table board;