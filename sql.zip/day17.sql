select runm, bbsno, userid, subject, masterid, replynumber, replystep
from (select rownum rnum, bbsno, userid, subject, masterid, replynumber, replystep
from (select bbsno, userid, subject, masterid, replynumber, replystep 
from board order by masterid desc, replynumber, replystep))
where rnum between 11 and 20;